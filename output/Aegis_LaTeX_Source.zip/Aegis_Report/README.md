# Aegis LaTeX report

Contributors: Ayush Pandey (24BIT0394) and Dheeraj Sutram (24BIT0416).

Compile from this folder with Tectonic:

    tectonic main.tex

The result is main.pdf. All referenced screenshots are included in screenshots/.
The source uses Latin Modern, black text, numbered sections, booktabs tables,
equations, a TikZ architecture figure and linked references.
